import json
from libpgm.graphskeleton import GraphSkeleton
from libpgm.pgmlearner import PGMLearner
import pickle

pkl_file = open('Data_Sample.pkl', 'rb')
datafile = pickle.load(pkl_file)
pkl_file.close()
data = datafile

print ('*************** Network Parameters *****************')
for skeleton in ["Network_skeleton.txt"]:
    skel = GraphSkeleton()
    skel.load(skeleton)
    learner = PGMLearner()
    result = learner.discrete_mle_estimateparams(skel, data)
    print json.dumps(result.Vdata, indent=2)

print ('*************** Network Edges *****************')
print json.dumps(result.E, indent=2)


print ('*************** Overload conditional probability *****************')
print result.Vdata["Outage_Duration"]["cprob"]