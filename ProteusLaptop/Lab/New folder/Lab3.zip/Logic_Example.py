__author__ = 'Hassan Nemati'

from pyDatalog import pyDatalog
import numpy as np

##  - you can assert logic sentences of the form head <= body, where head is a single literal with one or more variables,
#     and body is a list of literals separated by '&' : p(X) <= q(X) & R(X,Y)
#   - each variable in the head must also appear in the body.  The body may include equality and comparison predicates:
#     N1 == N-1, or N > 0, and contain lambda expressions
#   - you can negate a literal in the body: ~(p(X))
#   - the argument of a literal cannot be another predicate : p(q(a)) is not allowed
#   - you can define logic functions by a formula: p[X]=expression (similar to an assignment)
#   - you can define aggregate functions, e.g. p[X]=len(Y) <= body : len, sum, concat, min, max
#   - you can use prefixed literals and functions (e.g. Employee.name[X]==Y) to refer to python objects in logic
#     clauses, or to run logic queries in python programs

########################################################################################################################
print
print "Example 1"

# To declare the variables they must start with an upper-case letter
# Logic function names starts with a lower case
pyDatalog.create_terms('X, Y, indianFood, mildFood, chineseFood, likes')

+ indianFood('Curry')
+ indianFood('Kurma')
+ indianFood('Tandoori')
+ mildFood('Kurma')
+ mildFood('Tandoori')
+ mildFood('Pizza')
+ chineseFood('ChopSuey')


likes('Sam', X) <= (indianFood(X) & mildFood(X))
likes('Fred', X) <= mildFood(X)
likes('Fred', X) <= chineseFood(X)

# The result of a query is a set of its possible solutions, in random order. Each solution has 1 value for
# each variable in the query. The .data attribute gives access to the result.
print('-----------------Sam-----------------')
print(likes('Sam', X))
print('-----------------Fred-----------------')
print(likes('Fred', X))
print('-----------------List of foods that Fred likes-----------------')
print(X.data)
########################################################################################################################
print
print "Example 2"

Sensor_List = ['EnterHome', 'OutHome', 'InBed', 'OutBed', 'OnChairBed', 'OutChairBed', 'OnChairKitchen', 'OutChairKitchen',
               'Hallway', 'Kitchen', 'Bathroom', 'Bedroom', 'OpenDrawer', 'CloseDrawer', 'WaterOn',
               'WaterOff', 'CabinetOn', 'CabinetOff']

pyDatalog.create_terms('X, Y, Z, sensor, time')
+ sensor('OutBed', '2')
+ sensor('Bedroom', '3')
+ sensor('Bedroom', '4')
+ sensor('Bedroom', '5')
+ sensor('Kitchen', '6')
+ sensor('Kitchen', '7')
+ sensor('Kitchen', '8')

pyDatalog.create_terms('nextNr, greater, smaller')

for nr in range(10):
    + nextNr("%s" %nr, "%s" %(nr+1))

for nr1 in range(10):
    for nr2 in range(10):
        if nr1>nr2:
            + greater("%s" %nr1, "%s" %nr2)
        if nr1<nr2:
            + smaller("%s" %nr1, "%s" %nr2)

pyDatalog.create_terms('wakeUpAt, inBedroom, inKitchen')
wakeUpAt(X) <=  sensor('OutBed', X)
inBedroom(X) <=  sensor('Bedroom', X)
inKitchen(X) <=  sensor('Kitchen', X)

print('-----------------InBedroom-----------------')
print(inBedroom(X))
print('-----------------InKitchen-----------------')
print(inKitchen(X))

pyDatalog.create_terms('toEnterKitchen')
toEnterKitchen(X)  <= (inBedroom(X) & inKitchen(Y) & nextNr(X,Y))
print('-----------------ToEnterKitchen-----------------')
print(toEnterKitchen(X))

pyDatalog.create_terms('enterKitchenBefore')
enterKitchenBefore(X, Y) <=  (toEnterKitchen(X) & smaller(X,Y))
print('-----------------enterKitchenBefore 2-----------------')
print(enterKitchenBefore(X, '2'))     # this is false (notice empty list of solutions)
print('-----------------enterKitchenBefore 9-----------------')
print(enterKitchenBefore(X, '9'))     # while this is true
########################################################################################################################
print
print "Example 3"

pyDatalog.create_terms('agentHand, playerStack')

Stack = 100
if Stack>50:
    playerStack[Stack] = 'Large'
else:
    playerStack[Stack] = 'Small'


List_agentHand = ['OnePair', 'TwoPairs', 'ThreeOfKind', 'FullHouse', 'StraightFlush']
for i in range(len(List_agentHand)):
    + agentHand(List_agentHand[i])

pyDatalog.create_terms('weakHand, mediumHand, strongHand, agentAction')
+ weakHand('OnePair')
+ mediumHand('TwoPairs')
+ strongHand('ThreeOfKind')
+ strongHand('FullHouse')

agentAction('Raise',X) <= (agentHand(X) & strongHand(X))
agentAction('Raise',X) <= (agentHand(X) & mediumHand(X) & (playerStack[Stack] == 'Large'))
agentAction('Fold',X) <= (agentHand(X) & mediumHand(X) & (playerStack[Stack] == 'Large'))
agentAction('Fold',X) <=  (agentHand(X) & weakHand(X) & (playerStack[Stack] == 'Small'))
agentAction('Fold',X) <=  (agentHand(X) & weakHand(X))

print('-----------------Raise-----------------')
print(agentAction('Raise',X))          # change the Stack to 50 and try this again
print('-----------------Fold (large stack)-----------------')
print(agentAction('Fold',X))           # change the Stack to 50 and try this again




