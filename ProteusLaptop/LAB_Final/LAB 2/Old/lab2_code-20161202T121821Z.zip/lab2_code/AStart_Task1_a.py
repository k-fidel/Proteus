import Queue as queue
import numpy as np
import math
import PathPlanning as m_path
import matplotlib.pyplot as plt
import pickle

class Node(object):
    xPos =0
    yPos = 0
    cost =0
    f =0
    goTop = 0
    def __init__(self, xPos, yPos, cost , f,WayPonit2,WayPoint2):
        self.xPos = xPos
        self.yPos = yPos
        self.cost = cost
        self.f = f
        self.WayPoint1 = WayPoint1
        self.WayPoint2 = WayPoint2
    def UpDatef(self,x,y):
        self.f = self.cost + self.heuristic(x,y)

    def Move(self):
         self.cost +=1
    def heuristic(self,x,y):

        d = math.sqrt(math.pow((self.xPos - x), 2) + math.pow((self.yPos - y), 2))
        #if (self.xPos > 30 and self.yPos < self.WayPoint1[1]):
        #    d = math.sqrt(math.pow((self.xPos - x), 2) + math.pow((self.yPos - y), 2))
        #else:
        #    d= 10*(abs(self.yPos-self.WayPoint2[1])+abs(self.yPos - y))
        #d = max(abs(self.xPos - x) , abs(self.yPos - y))
        #if (y > 15 and x < 30):
        #    d = 2*d
        return  d

def Astart_PathFind(Map,PA,PB,WayPoint1,WayPoint2):
    dirs = 4                               # number of possible directions to move on the map
    if dirs == 4:
        dx = [1, 0, -1, 0]
        dy = [0, 1, 0, -1]
    n= Map.shape[0]
    m= Map.shape[1]
    xGoal = PB[0]
    yGoal = PB[1]
    path = np.zeros((n, m))
    solved_path = [[] for i in range(2)]
    path.fill(0)
    parents = np.zeros((n, m))
    parents= [[0 for i in range(n)] for j in range(m)]
    Open_list = queue.PriorityQueue()
    xS = PA[0]
    yS = PA[1]
    n0 = Node(xS,yS,0,0,WayPoint1,WayPoint2)
    n0.UpDatef(xGoal,yGoal)
    Open_list.put((n0.f,n0))

    #Map[xS][yS] = n0.f
    while not Open_list.empty():        # check the open list if there is any element for expanding
        temp = Open_list.get()       # read the low proirity element from the open list
        CurNode = temp[1]
        x = CurNode.xPos
        y = CurNode.yPos
        path[x][y] = 1
        if x == xGoal and y == yGoal:   # A* found the Goal

            solved_path[1].append(x)
            solved_path[0].append(y)
            cur = parents[x][y]
            x = cur[0]
            y = cur[1]
            while not (x == xS and y == yS ):
                solved_path[1].append(x)
                solved_path[0].append(y)
                cur = parents[x][y]
                x = cur[0]
                y= cur [1]
            solved_path[1].append(x)
            solved_path[0].append(y)

            return Map ,solved_path
        for i in range(dirs):
            xn = x+dx[i]
            yn = y+dy[i]
            if ( xn >=0 and yn >=0 and xn<=n-1 and yn<=m-1 and path[xn][yn] == 0 and (Map[xn][yn] == 1 or Map[xn][yn]==-3)):
                n0 = Node(xn, yn, CurNode.cost, CurNode.f,WayPoint1,WayPoint2)
                n0.Move()
                n0.UpDatef(xGoal,yGoal)
                Open_list.put((n0.f,n0))
                if(Map[xn][yn] <> -3):
                    Map[xn][yn] = n0.f
                parents[xn][yn]=[x,y]


##############  Main ########################################
thefile = open('map.txt', 'r')
n = 60
m = 60

Map2 = pickle.load(thefile)

#Map2 = m_path.generateMap2d_obstacle([60,60])
#Map = m_path.generateMap2d([n,m])
#Map = np.zeros((4,4))
#Map.fill(1)
#print  Map2[1]
Map = Map2[0]

for i in range(n):
    for j in range(m):
        if (Map[i][j] == -2):  #find the start point
            Sp= [i,j]
        if(Map[i][j] == -3):  # find the end point
            Ep = [i,j]
yS = Sp[0]
yF = Ep[0]
yTop = Map2[1][0]
yBot = Map2[1][1]

DisFormTop = abs(yS-yTop) + abs(yF-yTop)
DisFormBot = abs(yS-yBot) + abs(yF-yBot)

WayPoint1 = [n/2,yTop]
WayPoint2 = [n/2,yBot]


GoTop = 1
if(DisFormTop > DisFormBot):
    GoTop = 0
p = Astart_PathFind(Map,Sp,Ep,WayPoint1,WayPoint2)
path_ = p[1]
solved_map = p[0]
solved_map[solved_map==1]=0
m_path.plotMap(solved_map,path_)