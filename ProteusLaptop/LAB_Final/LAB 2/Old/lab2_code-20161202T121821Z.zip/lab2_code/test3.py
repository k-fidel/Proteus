import pickle
thefile = open('map.txt', 'r')

itemlist = pickle.load(thefile)
print itemlist