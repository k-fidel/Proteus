import matplotlib.pyplot as plt
import  pickle


thefile = open('test.txt', 'w')



m = [[] for j in range(2)]


for i in range(20):
    m[0].append(i)
    m[1].append(i)

pickle.dump(m, thefile)
